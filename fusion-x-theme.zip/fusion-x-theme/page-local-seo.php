<?php
/**
 * Template Name: Local SEO for GMB
 *
 * @package Fusion_X
 */

get_header();
?>

<style>
        :root {
            --dev-orange: #ff5722;
            --dev-orange-dark: #e64a19;
            --dev-dark: #0f172a;
            --dev-slate: #1e293b;
            --dev-muted: #64748b;
            --dev-bg-light: #f8fafc;
            --dev-border: rgba(226, 232, 240, 0.9);
        }

        body {
            font-family: 'Space Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #ffffff;
            color: #1e293b;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        /* ── HERO ── */
        .page-hero {
            padding: 150px 24px 80px;
            background: radial-gradient(circle at 50% 20%, rgba(255, 87, 34, 0.07) 0%, transparent 60%), #ffffff;
            text-align: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .badge-pill {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 8px 24px;
            background: rgba(255, 87, 34, 0.08);
            border: 1px solid rgba(255, 87, 34, 0.25);
            border-radius: 50px;
            font-size: 0.82rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: var(--dev-orange);
            margin-bottom: 24px;
        }

        .hero-title {
            font-family: 'Outfit', sans-serif;
            font-size: clamp(2.5rem, 5.5vw, 4.5rem);
            font-weight: 900;
            line-height: 1.08;
            letter-spacing: -1.5px;
            color: #0f172a;
            max-width: 980px;
            margin: 0 auto 24px;
        }

        .hero-title span {
            background: linear-gradient(135deg, #ff5722 20%, #ff8a50 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero-desc {
            font-size: clamp(1.05rem, 2vw, 1.25rem);
            line-height: 1.7;
            color: var(--dev-muted);
            max-width: 820px;
            margin: 0 auto 40px;
        }

        .tech-chips {
            display: flex;
            justify-content: center;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 50px;
        }

        .tech-chip {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 18px;
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 50px;
            font-size: 0.88rem;
            font-weight: 700;
            color: #334155;
            box-shadow: 0 4px 12px rgba(0,0,0,0.03);
        }

        .tech-chip i {
            color: var(--dev-orange);
        }

        .hero-ctas {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        .btn-primary-hero {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 16px 36px;
            background: var(--dev-orange);
            color: #ffffff;
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 700;
            font-size: 1rem;
            border-radius: 50px;
            text-decoration: none;
            box-shadow: 0 8px 25px rgba(255, 87, 34, 0.35);
            transition: all 0.3s ease;
        }

        .btn-primary-hero:hover {
            background: var(--dev-orange-dark);
            transform: translateY(-2px);
            box-shadow: 0 12px 30px rgba(255, 87, 34, 0.45);
        }

        .btn-secondary-hero {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 16px 36px;
            background: #ffffff;
            color: #0f172a;
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 700;
            font-size: 1rem;
            border-radius: 50px;
            border: 2px solid #e2e8f0;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .btn-secondary-hero:hover {
            border-color: #cbd5e1;
            background: #f8fafc;
            transform: translateY(-2px);
        }

        /* ── CONTENT CONTAINER ── */
        .content-section {
            padding: 90px 24px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .service-card-block {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px;
            align-items: center;
            padding: 60px 0;
            border-bottom: 1px solid #f1f5f9;
        }

        .service-card-block:nth-child(even) {
            direction: rtl;
        }

        .service-card-block:nth-child(even) .card-text-col {
            direction: ltr;
        }

        .service-card-block:nth-child(even) .card-visual-box {
            direction: ltr;
        }

        .card-tag {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 0.8rem;
            font-weight: 700;
            color: var(--dev-orange);
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-bottom: 12px;
        }

        .card-title {
            font-family: 'Outfit', sans-serif;
            font-size: clamp(1.8rem, 3.2vw, 2.6rem);
            font-weight: 800;
            color: #0f172a;
            line-height: 1.2;
            margin-bottom: 18px;
        }

        .card-desc {
            font-size: 1.05rem;
            line-height: 1.7;
            color: var(--dev-muted);
            margin-bottom: 24px;
        }

        .card-feature-list {
            list-style: none;
            padding: 0;
            margin: 0 0 30px;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .card-feature-list li {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.95rem;
            font-weight: 600;
            color: #334155;
        }

        .card-feature-list li i {
            color: var(--dev-orange);
            font-size: 1rem;
        }

        .card-tech-tag {
            display: inline-block;
            background: #f1f5f9;
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 700;
            color: #475569;
            margin-right: 8px;
            margin-bottom: 6px;
        }

        .card-visual-box {
            background: linear-gradient(135deg, #f8fafc 0%, #edf2f7 100%);
            border: 1px solid #e2e8f0;
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.05);
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .card-visual-icon {
            font-size: 3.8rem;
            color: var(--dev-orange);
            margin-bottom: 18px;
        }

        .card-visual-stat {
            font-family: 'Outfit', sans-serif;
            font-size: 2.8rem;
            font-weight: 900;
            color: #0f172a;
            margin-bottom: 6px;
        }

        .card-visual-sub {
            font-size: 0.92rem;
            color: var(--dev-muted);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* ── PROTOCOL STEPS ── */
        .process-section {
            background: #080808;
            color: #ffffff;
            padding: 100px 24px;
            border-radius: 36px;
            margin: 60px 24px;
        }

        .process-header {
            text-align: center;
            max-width: 700px;
            margin: 0 auto 60px;
        }

        .process-header h2 {
            font-family: 'Outfit', sans-serif;
            font-size: clamp(2rem, 4vw, 3rem);
            font-weight: 800;
            margin-bottom: 16px;
        }

        .process-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 24px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .process-card {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 20px;
            padding: 32px 24px;
            position: relative;
        }

        .step-num {
            font-family: 'Outfit', sans-serif;
            font-size: 2.5rem;
            font-weight: 900;
            color: rgba(255, 87, 34, 0.4);
            margin-bottom: 12px;
        }

        .step-title {
            font-size: 1.15rem;
            font-weight: 700;
            margin-bottom: 10px;
            color: #ffffff;
        }

        .step-desc {
            font-size: 0.92rem;
            color: #94a3b8;
            line-height: 1.6;
        }

        /* ── CTA BANNER ── */
        .cta-banner {
            background: #080808; border: 1px solid rgba(255, 87, 34, 0.3);
            border-radius: 28px;
            padding: 60px 40px;
            text-align: center;
            color: #ffffff;
            margin: 60px auto 0;
            max-width: 1100px;
            box-shadow: 0 20px 50px rgba(15, 23, 42, 0.2);
        }

        .cta-banner h2 {
            font-family: 'Outfit', sans-serif;
            font-size: clamp(2rem, 4vw, 3rem);
            font-weight: 900;
            margin-bottom: 14px;
        }

        .cta-banner p {
            font-size: 1.1rem;
            color: #cbd5e1;
            max-width: 650px;
            margin: 0 auto 30px;
        }

        @media (max-width: 900px) {
            .service-card-block {
                grid-template-columns: 1fr;
                gap: 30px;
                padding: 40px 0;
            }
            .service-card-block:nth-child(even) {
                direction: ltr;
            }
            .process-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>

<!-- ═══════════════════════ HERO ═══════════════════════ -->
    <header class="page-hero">
        <div class="badge-pill">
            <i class="fa-solid fa-location-dot"></i> LOCAL SEO & GOOGLE MAPS 3-PACK
        </div>
        <h1 class="hero-title">
            Dominate Google Maps & <span>Capture High-Intent Local Customers</span>
        </h1>
        <p class="hero-desc">
            46% of all Google searches have direct local commercial intent. We optimize your Google Business Profile (GBP), expand your geo-grid ranking radius, and synchronize citations across 80+ directories to keep your business #1 in the Local 3-Pack.
        </p>
        <div class="tech-chips">
            <div class="tech-chip"><i class="fa-solid fa-map-location-dot"></i> Google Maps 3-Pack #1</div>
            <div class="tech-chip"><i class="fa-solid fa-compass"></i> Geo-Grid Radius Expansion</div>
            <div class="tech-chip"><i class="fa-solid fa-address-book"></i> 80+ Verified NAP Citations</div>
            <div class="tech-chip"><i class="fa-solid fa-star"></i> Review Acceleration Engine</div>
            <div class="tech-chip"><i class="fa-solid fa-phone"></i> Inbound Phone Call Surges</div>
        </div>
        <div class="hero-ctas">
            <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn-primary-hero">Get Free Local Geo-Grid Audit <i class="fa-solid fa-arrow-right"></i></a>
            <a href="#gmb-optimization" class="btn-secondary-hero">Explore Local SEO Vectors</a>
        </div>
    </header>

    <!-- ═══════════════════════ SERVICES BREAKDOWN ═══════════════════════ -->
    <main class="content-section">

        <!-- Card 1: Google Business Profile 100% Optimization -->
        <div class="service-card-block" id="gmb-optimization">
            <div class="card-text-col">
                <span class="card-tag"><i class="fa-solid fa-store"></i> Google Profile</span>
                <h2 class="card-title">Google Business Profile (GBP) Optimization</h2>
                <p class="card-desc">
                    Your Google Business Profile is your digital storefront. We meticulously configure your primary and secondary categories, inject localized semantic keywords into your description, upload geotagged high-res images, and keep your profile dynamically updated.
                </p>
                <ul class="card-feature-list">
                    <li><i class="fa-solid fa-circle-check"></i> High-conversion primary & secondary business category architecture</li>
                    <li><i class="fa-solid fa-circle-check"></i> Geotagged metadata embedded in all uploaded store and team imagery</li>
                    <li><i class="fa-solid fa-circle-check"></i> Weekly keyword-optimized Google Posts with trackable call-to-action buttons</li>
                    <li><i class="fa-solid fa-circle-check"></i> FAQ question-and-answer seeding addressing high-intent customer inquiries</li>
                </ul>
                <div class="card-tech-tags">
                    <span class="card-tech-tag">GBP Verified</span>
                    <span class="card-tech-tag">Geotagged Images</span>
                    <span class="card-tech-tag">Google Posts</span>
                    <span class="card-tech-tag">Category Optimization</span>
                </div>
            </div>
            <div class="card-visual-box">
                <i class="fa-solid fa-map-pin card-visual-icon"></i>
                <div class="card-visual-stat">Top 3</div>
                <div class="card-visual-sub">Google Maps 3-Pack Placement</div>
            </div>
        </div>

        <!-- Card 2: Geo-Grid Proximity & Radius Expansion -->
        <div class="service-card-block" id="geo-grid-tracking">
            <div class="card-text-col">
                <span class="card-tag"><i class="fa-solid fa-draw-polygon"></i> Proximity Expansion</span>
                <h2 class="card-title">Geo-Grid Radius Expansion & Proximity Tracking</h2>
                <p class="card-desc">
                    Most businesses only rank for customers standing right outside their door. Our hyper-local proximity optimization builds local landing pages and neighborhood signals that expand your ranking radius across 10 to 25 square kilometers.
                </p>
                <ul class="card-feature-list">
                    <li><i class="fa-solid fa-circle-check"></i> Pin-by-pin geo-grid tracking measuring keyword rankings across multiple suburbs</li>
                    <li><i class="fa-solid fa-circle-check"></i> Dedicated suburb and neighborhood landing pages with local schema markup</li>
                    <li><i class="fa-solid fa-circle-check"></i> Driving directions integration and localized landmark co-occurrences</li>
                    <li><i class="fa-solid fa-circle-check"></i> Progressive elimination of red low-ranking nodes on your local geo-map</li>
                </ul>
                <div class="card-tech-tags">
                    <span class="card-tech-tag">Geo-Grid Tracking</span>
                    <span class="card-tech-tag">Proximity Boost</span>
                    <span class="card-tech-tag">Neighborhood Silos</span>
                    <span class="card-tech-tag">Local Business Schema</span>
                </div>
            </div>
            <div class="card-visual-box">
                <i class="fa-solid fa-bullseye-arrow card-visual-icon"></i>
                <div class="card-visual-stat">+240%</div>
                <div class="card-visual-sub">Ranking Radius Expansion</div>
            </div>
        </div>

        <!-- Card 3: 100% NAP Citation Consistency -->
        <div class="service-card-block" id="citation-building">
            <div class="card-text-col">
                <span class="card-tag"><i class="fa-solid fa-building-circle-check"></i> Citation Accuracy</span>
                <h2 class="card-title">NAP Citation Building & Duplicate Cleanup</h2>
                <p class="card-desc">
                    Inconsistent business names, old phone numbers, or mismatched addresses confuse Google's local algorithm. We audit, clean up, and synchronize your exact NAP credentials across 80+ authoritative business directories and mapping apps.
                </p>
                <ul class="card-feature-list">
                    <li><i class="fa-solid fa-circle-check"></i> 100% precision Name, Address, and Phone (NAP) synchronization</li>
                    <li><i class="fa-solid fa-circle-check"></i> Aggressive duplicate listing suppression and rogue entry merges</li>
                    <li><i class="fa-solid fa-circle-check"></i> Submissions to Justdial, Sulekha, IndiaMART, Apple Maps, and Bing Places</li>
                    <li><i class="fa-solid fa-circle-check"></i> Niche-specific local chamber of commerce and trade association citations</li>
                </ul>
                <div class="card-tech-tags">
                    <span class="card-tech-tag">NAP Consistency</span>
                    <span class="card-tech-tag">80+ Directories</span>
                    <span class="card-tech-tag">Apple Maps</span>
                    <span class="card-tech-tag">Duplicate Cleanup</span>
                </div>
            </div>
            <div class="card-visual-box">
                <i class="fa-solid fa-badge-check card-visual-icon"></i>
                <div class="card-visual-stat">100%</div>
                <div class="card-visual-sub">Citation Consistency Score</div>
            </div>
        </div>

        <!-- Card 4: Review Acceleration & Reputation Engineering -->
        <div class="service-card-block" id="review-acceleration">
            <div class="card-text-col">
                <span class="card-tag"><i class="fa-solid fa-star-half-stroke"></i> Social Proof</span>
                <h2 class="card-title">Review Acceleration Funnels & Sentiment Management</h2>
                <p class="card-desc">
                    Review velocity and keyword-rich customer testimonials are among the top 3 ranking factors for Google Maps. We implement frictionless QR code and WhatsApp review request funnels that steadily generate 5-star Google reviews.
                </p>
                <ul class="card-feature-list">
                    <li><i class="fa-solid fa-circle-check"></i> Frictionless one-tap Google review link shorteners and in-store QR stands</li>
                    <li><i class="fa-solid fa-circle-check"></i> Automated WhatsApp and SMS review request flows triggered post-service</li>
                    <li><i class="fa-solid fa-circle-check"></i> Keyword-rich owner responses reinforcing semantic relevance for Google</li>
                    <li><i class="fa-solid fa-circle-check"></i> Proactive escalation protocols to protect your 4.8+ star rating</li>
                </ul>
                <div class="card-tech-tags">
                    <span class="card-tech-tag">5-Star Velocity</span>
                    <span class="card-tech-tag">WhatsApp Funnel</span>
                    <span class="card-tech-tag">QR Code Review</span>
                    <span class="card-tech-tag">Sentiment SEO</span>
                </div>
            </div>
            <div class="card-visual-box">
                <i class="fa-solid fa-phone-volume card-visual-icon"></i>
                <div class="card-visual-stat">+180%</div>
                <div class="card-visual-sub">Inbound Call & Direction Requests</div>
            </div>
        </div>

    </main>

    <!-- ═══════════════════════ PROCESS SECTION ═══════════════════════ -->
    
    <!-- ═══════════════════════ TEAM SPECIALIST SPOTLIGHT ═══════════════════════ -->
    <section class="expert-spotlight-section">
        <div class="expert-spotlight-card">
            <div class="expert-avatar-wrap">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/team/saravana-sanjhay-m-seo-expert.webp" alt="Saravana Sanjhay M - Best SEO Expert" class="expert-avatar-img">
                <div class="expert-verified-badge"><i class="fa-solid fa-check"></i></div>
            </div>
            <div class="expert-content">
                <div class="expert-domain-pill"><i class="fa-solid fa-magnifying-glass-chart"></i> Technical SEO & AI Search Lead</div>
                <h3 class="expert-name">Saravana Sanjhay M</h3>
                <div class="expert-headline">
                    <i class="fa-solid fa-award" style="color: #ff5722;"></i>
                    <strong>best seo expert our company Saravana Sanjhay.M</strong>
                </div>
                <p class="expert-bio">
                    Recognized among the <strong>top 10 seo ai experts</strong> in India, Saravana Sanjhay M leads Fusion X with deep mastery of <strong>technical seo vs on page seo</strong>. His proprietary systems are engineered to <strong>bring your brand in google search</strong> and sustainably <strong>bring organic traffic</strong> that accelerates client revenue. When ambitious brands choose to <strong>hire seo expert in india</strong>, Saravana ensures cutting-edge <strong>ai seo done to bring in ai search</strong> (ChatGPT Search, Perplexity AI, Google Gemini, and AI Overviews), alongside delivering the <strong>best ecommerce seo services in india</strong> for high-converting stores.
                </p>
                <div class="expert-stats-row">
                    <div class="expert-stat-item">
                        <span class="expert-stat-val">+280%</span>
                        <span class="expert-stat-lbl">Avg Organic Traffic Lift</span>
                    </div>
                    <div class="expert-stat-item">
                        <span class="expert-stat-val">Top 3</span>
                        <span class="expert-stat-lbl">Maps 3-Pack Rate</span>
                    </div>
                    <div class="expert-stat-item">
                        <span class="expert-stat-val">100%</span>
                        <span class="expert-stat-lbl">White-Hat & AI Entity SEO</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="process-section">
        <div class="process-header">
            <span class="badge-pill" style="background: rgba(255,87,34,0.15); border-color: rgba(255,87,34,0.35);">
                EXECUTION PROTOCOL
            </span>
            <h2>Our 4-Step Local Domination Blueprint</h2>
            <p style="color: #94a3b8; font-size: 1.05rem;">From initial baseline geo-grid audit to complete Google Maps 3-pack leadership.</p>
        </div>
        <div class="process-grid">
            <div class="process-card">
                <div class="step-num">01</div>
                <h3 class="step-title">Geo-Grid Audit</h3>
                <p class="step-desc">Scan your target city using a 10km grid to document your baseline ranking positions for high-intent search terms.</p>
            </div>
            <div class="process-card">
                <div class="step-num">02</div>
                <h3 class="step-title">GBP Optimization</h3>
                <p class="step-desc">Refactor categories, upload geotagged images, draft localized service descriptions, and seed Q&A responses.</p>
            </div>
            <div class="process-card">
                <div class="step-num">03</div>
                <h3 class="step-title">Citation Cleanup</h3>
                <p class="step-desc">Lock in 100% identical NAP details across 80+ authoritative Indian and global business directories.</p>
            </div>
            <div class="process-card">
                <div class="step-num">04</div>
                <h3 class="step-title">Review Funnels</h3>
                <p class="step-desc">Launch automated WhatsApp review funnels to drive continuous 5-star customer feedback and expand your radius.</p>
            </div>
        </div>
    </section>

    <!-- ═══════════════════════ CTA BANNER ═══════════════════════ -->
    <div class="content-section" style="padding-top: 0; padding-bottom: 0;">
        <div class="cta-banner">
            <h2>Ready to Be the First Choice for Local Buyers?</h2>
            <p>Request a complimentary geo-grid heat map analysis of your business in your city today.</p>
            <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn-primary-hero" style="background: #ff5722;">Claim Your Free Local Audit <i class="fa-solid fa-arrow-right"></i></a>
        </div>
    </div>

    <!-- ═══════════════════════ FOOTER ═══════════════════════ -->

<?php
get_footer();
