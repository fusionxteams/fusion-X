<?php
/**
 * Template Name: Digital Marketing Services
 *
 * @package Fusion_X
 */

get_header();
?>

<style>
        /* ==========================================================================
           2026 AWWWARDS-TIER DESIGN SYSTEM: CLEAN WHITE LUXE & SOLAR ORANGE ACCENT
           ========================================================================== */
        :root {
            --fx-bg: #ffffff;
            --fx-bg-subtle: #f8fafc;
            --fx-bg-alt: #f1f5f9;
            --fx-surface: #ffffff;
            --fx-surface-hover: #ffffff;
            --fx-surface-glass: rgba(255, 255, 255, 0.88);
            --fx-border: rgba(0, 0, 0, 0.07);
            --fx-border-hover: rgba(255, 87, 34, 0.45);
            --fx-border-glow: rgba(255, 87, 34, 0.25);
            --fx-orange: #FF5722;
            --fx-orange-hover: #f4511e;
            --fx-orange-glow: rgba(255, 87, 34, 0.2);
            --fx-orange-subtle: rgba(255, 87, 34, 0.08);
            --fx-orange-tint: #fff6f2;
            --fx-amber: #e65100;
            --fx-text-primary: #0f172a;
            --fx-text-secondary: #475569;
            --fx-text-muted: #64748b;
            --fx-radius-sm: 10px;
            --fx-radius-md: 18px;
            --fx-radius-lg: 26px;
            --fx-radius-xl: 36px;
            --fx-font-display: 'Outfit', sans-serif;
            --fx-font-body: 'Space Grotesk', sans-serif;
            --fx-font-sans: 'Inter', sans-serif;
            --fx-transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        }

        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            scroll-behavior: smooth;
            background-color: var(--fx-bg);
            color: var(--fx-text-primary);
        }

        body {
            font-family: var(--fx-font-body);
            background-color: var(--fx-bg);
            color: var(--fx-text-primary);
            line-height: 1.6;
            overflow-x: hidden;
            position: relative;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        /* Subtle Geometric Dot Grid Pattern on Pure White */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image: radial-gradient(#cbd5e1 1.1px, transparent 1.1px);
            background-size: 32px 32px;
            opacity: 0.45;
            pointer-events: none;
            z-index: 0;
        }

        /* Ambient Warm Peach & Solar Orange Glow Orbs */
        .ambient-glow-top {
            position: absolute;
            top: -150px;
            left: 50%;
            transform: translateX(-50%);
            width: 1100px;
            height: 600px;
            background: radial-gradient(ellipse at 50% 30%, rgba(255, 87, 34, 0.12) 0%, rgba(255, 171, 145, 0.06) 50%, transparent 75%);
            pointer-events: none;
            z-index: 0;
        }

        /* Universal Container */
        .container {
            width: 100%;
            max-width: 1360px;
            margin: 0 auto;
            padding: 0 28px;
            position: relative;
            z-index: 1;
        }

        /* Typography Defaults */
        h1, h2, h3, h4, h5, h6 {
            font-family: var(--fx-font-display);
            font-weight: 800;
            color: var(--fx-text-primary);
            letter-spacing: -0.03em;
        }

        p {
            color: var(--fx-text-secondary);
            font-size: 1.05rem;
            line-height: 1.7;
        }

        a {
            color: inherit;
            text-decoration: none;
            transition: var(--fx-transition);
        }


        /* ==========================================================================
           2026 KINETIC HERO SECTION (CLEAN WHITE)
           ========================================================================== */
        .services-hero {
            padding: 160px 0 90px;
            position: relative;
            text-align: center;
            overflow: hidden;
        }

        .hero-badge-pill {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: #ffffff;
            border: 1px solid rgba(255, 87, 34, 0.25);
            padding: 8px 22px;
            border-radius: 50px;
            font-size: 0.85rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: var(--fx-orange);
            margin-bottom: 26px;
            box-shadow: 0 4px 18px rgba(255, 87, 34, 0.08);
        }

        .pulse-dot {
            width: 8px;
            height: 8px;
            background-color: var(--fx-orange);
            border-radius: 50%;
            box-shadow: 0 0 10px var(--fx-orange);
            animation: pulseRadar 2s infinite;
        }

        @keyframes pulseRadar {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(255, 87, 34, 0.6); }
            70% { transform: scale(1.1); box-shadow: 0 0 0 8px rgba(255, 87, 34, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(255, 87, 34, 0); }
        }

        .hero-title-massive {
            font-size: clamp(2.8rem, 6.2vw, 5.8rem);
            font-weight: 900;
            line-height: 1.05;
            max-width: 1100px;
            margin: 0 auto 26px;
            letter-spacing: -0.04em;
            color: #0f172a;
        }

        .gradient-orange-text {
            background: linear-gradient(135deg, var(--fx-orange) 0%, #e65100 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero-description-lead {
            font-size: clamp(1.1rem, 2vw, 1.32rem);
            color: var(--fx-text-secondary);
            max-width: 840px;
            margin: 0 auto 44px;
            line-height: 1.7;
        }

        .hero-actions-group {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 18px;
            flex-wrap: wrap;
            margin-bottom: 64px;
        }

        .btn-primary-glow {
            background: linear-gradient(135deg, var(--fx-orange) 0%, #e64a19 100%);
            color: #ffffff;
            font-family: var(--fx-font-display);
            font-weight: 700;
            font-size: 1.05rem;
            padding: 16px 36px;
            border-radius: 50px;
            display: inline-flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 8px 24px rgba(255, 87, 34, 0.28);
        }

        .btn-primary-glow:hover {
            transform: translateY(-3px);
            box-shadow: 0 14px 34px rgba(255, 87, 34, 0.42);
        }

        .btn-secondary-glass {
            background: #ffffff;
            color: var(--fx-text-primary);
            font-family: var(--fx-font-display);
            font-weight: 600;
            font-size: 1.05rem;
            padding: 16px 32px;
            border-radius: 50px;
            border: 1px solid var(--fx-border);
            display: inline-flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.04);
        }

        .btn-secondary-glass:hover {
            border-color: rgba(0, 0, 0, 0.18);
            transform: translateY(-3px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
        }

        /* 4 Stat Verification Capsules */
        .hero-stats-matrix {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .stat-capsule-card {
            background: #ffffff;
            border: 1px solid var(--fx-border);
            border-radius: var(--fx-radius-md);
            padding: 24px 20px;
            text-align: left;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
            transition: var(--fx-transition);
        }

        .stat-capsule-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: var(--fx-orange);
            opacity: 0.8;
        }

        .stat-capsule-card:hover {
            border-color: var(--fx-border-hover);
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(255, 87, 34, 0.1), 0 4px 12px rgba(0, 0, 0, 0.04);
        }

        .stat-number-accent {
            font-family: var(--fx-font-display);
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--fx-text-primary);
            line-height: 1;
            margin-bottom: 6px;
        }

        .stat-label-title {
            font-size: 0.95rem;
            font-weight: 700;
            color: var(--fx-orange);
            margin-bottom: 4px;
        }

        .stat-specialist-info {
            font-size: 0.82rem;
            color: var(--fx-text-muted);
            line-height: 1.4;
        }

        /* ==========================================================================
           INTERACTIVE 2026 BENTO GRID SERVICES CATALOG (CLEAN LIGHT THEME)
           ========================================================================== */
        .services-bento-section {
            padding: 120px 0;
            background: var(--fx-bg-subtle);
            border-top: 1px solid var(--fx-border);
            border-bottom: 1px solid var(--fx-border);
            position: relative;
        }

        .section-header-box {
            text-align: center;
            max-width: 820px;
            margin: 0 auto 54px;
        }

        .section-subtag-pill {
            display: inline-block;
            color: var(--fx-orange);
            font-size: 0.85rem;
            font-weight: 800;
            letter-spacing: 2.5px;
            text-transform: uppercase;
            margin-bottom: 14px;
        }

        .section-title-huge {
            font-size: clamp(2.4rem, 4.5vw, 3.8rem);
            margin-bottom: 18px;
            letter-spacing: -0.03em;
            color: var(--fx-text-primary);
        }

        .section-subtitle-muted {
            font-size: 1.15rem;
            color: var(--fx-text-secondary);
        }

        /* Filter Tabs */
        .filter-controls-row {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
            gap: 12px;
            margin-bottom: 48px;
        }

        .service-filter-btn {
            background: #ffffff;
            border: 1px solid var(--fx-border);
            color: var(--fx-text-secondary);
            font-family: var(--fx-font-body);
            font-size: 0.9rem;
            font-weight: 600;
            padding: 10px 22px;
            border-radius: 50px;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
            transition: var(--fx-transition);
        }

        .service-filter-btn:hover {
            color: var(--fx-text-primary);
            border-color: rgba(0, 0, 0, 0.2);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }

        .service-filter-btn.active {
            background: linear-gradient(135deg, var(--fx-orange) 0%, #e64a19 100%);
            color: #ffffff;
            border-color: var(--fx-orange);
            box-shadow: 0 4px 18px rgba(255, 87, 34, 0.28);
        }

        /* Asymmetric Bento Grid (Crisp White Cards) */
        .bento-services-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 24px;
        }

        .bento-card-unit {
            background: #ffffff;
            border: 1px solid var(--fx-border);
            border-radius: var(--fx-radius-lg);
            padding: 38px 32px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 24px rgba(0, 0, 0, 0.03);
            transition: var(--fx-transition);
        }

        .bento-card-unit::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(circle at 100% 0%, rgba(255, 87, 34, 0.08) 0%, transparent 65%);
            opacity: 0;
            transition: opacity 0.5s ease;
            pointer-events: none;
        }

        .bento-card-unit:hover {
            transform: translateY(-6px);
            border-color: var(--fx-border-hover);
            box-shadow: 0 20px 45px rgba(255, 87, 34, 0.08), 0 4px 16px rgba(0, 0, 0, 0.04);
        }

        .bento-card-unit:hover::before {
            opacity: 1;
        }

        /* Asymmetry Spans */
        .bento-card-unit.span-2 {
            grid-column: span 2;
        }

        .bento-card-unit.span-3 {
            grid-column: span 3;
            flex-direction: row;
            align-items: center;
            gap: 40px;
        }

        .bento-card-unit.span-3 .card-main-content {
            flex: 1;
        }

        .card-top-meta {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }

        .card-tag-pill {
            background: var(--fx-orange-subtle);
            color: var(--fx-orange);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 5px 14px;
            border-radius: 30px;
            border: 1px solid rgba(255, 87, 34, 0.2);
        }

        .card-specialist-chip {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 0.8rem;
            color: var(--fx-text-muted);
            font-weight: 500;
        }

        .card-specialist-chip i {
            color: var(--fx-orange);
        }

        .card-icon-avatar {
            width: 58px;
            height: 58px;
            border-radius: var(--fx-radius-md);
            background: var(--fx-orange-tint);
            border: 1px solid rgba(255, 87, 34, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--fx-orange);
            margin-bottom: 22px;
            transition: var(--fx-transition);
        }

        .bento-card-unit:hover .card-icon-avatar {
            background: var(--fx-orange);
            color: #ffffff;
            transform: scale(1.08) rotate(4deg);
            box-shadow: 0 8px 20px rgba(255, 87, 34, 0.3);
        }

        .card-title-heading {
            font-size: 1.85rem;
            line-height: 1.2;
            margin-bottom: 16px;
            color: var(--fx-text-primary);
        }

        .card-feature-bullets {
            list-style: none;
            margin-bottom: 30px;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .card-feature-bullets li {
            font-size: 0.95rem;
            color: var(--fx-text-secondary);
            display: flex;
            align-items: flex-start;
            gap: 10px;
            line-height: 1.55;
        }

        .card-feature-bullets li i {
            color: var(--fx-orange);
            font-size: 0.85rem;
            margin-top: 4px;
            flex-shrink: 0;
        }

        .card-action-link {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-weight: 700;
            font-size: 0.92rem;
            color: var(--fx-text-primary);
            padding-top: 18px;
            border-top: 1px solid rgba(0, 0, 0, 0.06);
        }

        .card-action-link i {
            color: var(--fx-orange);
            transition: transform 0.3s ease;
        }

        .bento-card-unit:hover .card-action-link i {
            transform: translateX(6px);
        }

        /* ==========================================================================
           2026 CAPABILITIES COMMAND DECK (CLEAN WHITE COCKPIT)
           ========================================================================== */
        .capabilities-deck-section {
            padding: 130px 0;
            background: #ffffff;
            position: relative;
        }

        .deck-cockpit-layout {
            display: grid;
            grid-template-columns: 340px 1fr;
            gap: 36px;
            background: #ffffff;
            border: 1px solid var(--fx-border);
            border-radius: var(--fx-radius-xl);
            padding: 36px;
            box-shadow: 0 16px 50px rgba(0, 0, 0, 0.05);
        }

        .deck-nav-sidebar {
            display: flex;
            flex-direction: column;
            gap: 10px;
            border-right: 1px solid var(--fx-border);
            padding-right: 28px;
        }

        .deck-tab-btn {
            background: transparent;
            border: 1px solid transparent;
            padding: 16px 18px;
            border-radius: var(--fx-radius-md);
            text-align: left;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 16px;
            color: var(--fx-text-secondary);
            font-family: var(--fx-font-body);
            font-size: 0.98rem;
            font-weight: 600;
            transition: var(--fx-transition);
        }

        .deck-tab-btn:hover {
            background: var(--fx-bg-subtle);
            color: var(--fx-text-primary);
        }

        .deck-tab-btn.active {
            background: #ffffff;
            border-color: rgba(255, 87, 34, 0.3);
            color: var(--fx-text-primary);
            box-shadow: 0 6px 20px rgba(255, 87, 34, 0.08), 0 2px 8px rgba(0, 0, 0, 0.03);
        }

        .deck-tab-btn.active .tab-icon-box {
            background: var(--fx-orange);
            color: #ffffff;
            box-shadow: 0 4px 12px rgba(255, 87, 34, 0.35);
        }

        .tab-icon-box {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: var(--fx-bg-subtle);
            border: 1px solid var(--fx-border);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.15rem;
            color: var(--fx-text-muted);
            transition: var(--fx-transition);
        }

        .deck-tab-content-panel {
            padding: 10px 16px;
        }

        .stage-view-card {
            display: none;
            animation: fadeInStage 0.35s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }

        .stage-view-card.active {
            display: block;
        }

        @keyframes fadeInStage {
            from { opacity: 0; transform: translateY(12px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .stage-metric-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: var(--fx-orange-subtle);
            border: 1px solid var(--fx-border-glow);
            padding: 8px 18px;
            border-radius: 30px;
            color: var(--fx-orange);
            font-weight: 700;
            font-size: 0.88rem;
            margin-bottom: 20px;
        }

        .stage-title {
            font-size: clamp(2rem, 3.2vw, 2.8rem);
            margin-bottom: 18px;
            color: var(--fx-text-primary);
        }

        .stage-lead-p {
            font-size: 1.15rem;
            color: var(--fx-text-secondary);
            margin-bottom: 36px;
            max-width: 820px;
        }

        .stage-grid-quad {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 40px;
        }

        .quad-item-card {
            background: var(--fx-bg-subtle);
            border: 1px solid var(--fx-border);
            border-radius: var(--fx-radius-md);
            padding: 24px;
            transition: var(--fx-transition);
        }

        .quad-item-card:hover {
            border-color: rgba(255, 87, 34, 0.3);
            background: #ffffff;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.04);
        }

        .quad-item-card h4 {
            font-size: 1.2rem;
            color: var(--fx-text-primary);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .quad-item-card h4 i {
            color: var(--fx-orange);
            font-size: 1rem;
        }

        .quad-item-card p {
            font-size: 0.92rem;
            color: var(--fx-text-muted);
            line-height: 1.6;
        }

        .stage-specialist-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-top: 28px;
            border-top: 1px solid var(--fx-border);
            flex-wrap: wrap;
            gap: 20px;
        }

        .specialist-person-bar {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .specialist-initials-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: var(--fx-orange-tint);
            border: 2px solid var(--fx-orange);
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: var(--fx-font-display);
            font-weight: 800;
            color: var(--fx-orange);
            font-size: 1.1rem;
        }

        .specialist-detail-names h5 {
            font-size: 1.05rem;
            color: var(--fx-text-primary);
            margin-bottom: 2px;
        }

        .specialist-detail-names span {
            font-size: 0.85rem;
            color: var(--fx-text-muted);
        }

        /* ==========================================================================
           CHENNAI LOCAL SERVICE HUBS (CLEAN WHITE)
           ========================================================================== */
        .local-hubs-section {
            padding: 120px 0;
            background: var(--fx-bg-subtle);
            border-top: 1px solid var(--fx-border);
            border-bottom: 1px solid var(--fx-border);
        }

        .locality-corridor-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .locality-hub-card {
            background: #ffffff;
            border: 1px solid var(--fx-border);
            border-radius: var(--fx-radius-md);
            padding: 28px 24px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.02);
            transition: var(--fx-transition);
            position: relative;
            overflow: hidden;
        }

        .locality-hub-card:hover {
            transform: translateY(-5px);
            border-color: var(--fx-border-hover);
            box-shadow: 0 14px 30px rgba(255, 87, 34, 0.08), 0 2px 8px rgba(0, 0, 0, 0.03);
        }

        .locality-top-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 14px;
        }

        .locality-name-h4 {
            font-size: 1.35rem;
            color: var(--fx-text-primary);
        }

        .locality-pin-icon {
            color: var(--fx-orange);
            font-size: 1.1rem;
        }

        .locality-corridor-desc {
            font-size: 0.85rem;
            color: var(--fx-text-muted);
            margin-bottom: 16px;
        }

        .locality-client-tag {
            display: inline-block;
            background: var(--fx-orange-subtle);
            color: var(--fx-orange);
            font-size: 0.8rem;
            font-weight: 700;
            padding: 4px 12px;
            border-radius: 20px;
            border: 1px solid rgba(255, 87, 34, 0.2);
        }

        /* ==========================================================================
           INDUSTRIES GRID (CLEAN WHITE)
           ========================================================================== */
        .industries-section {
            padding: 120px 0;
            background: #ffffff;
        }

        .industries-cards-matrix {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 24px;
        }

        .industry-card-item {
            background: #ffffff;
            border: 1px solid var(--fx-border);
            border-radius: var(--fx-radius-lg);
            padding: 36px 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.02);
            transition: var(--fx-transition);
        }

        .industry-card-item:hover {
            transform: translateY(-5px);
            border-color: var(--fx-border-hover);
            box-shadow: 0 16px 36px rgba(255, 87, 34, 0.08), 0 2px 8px rgba(0, 0, 0, 0.03);
        }

        .industry-icon-pill {
            width: 52px;
            height: 52px;
            border-radius: 14px;
            background: var(--fx-orange-tint);
            border: 1px solid rgba(255, 87, 34, 0.15);
            color: var(--fx-orange);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
            margin-bottom: 20px;
        }

        .industry-title {
            font-size: 1.45rem;
            color: var(--fx-text-primary);
            margin-bottom: 12px;
        }

        .industry-card-item p {
            font-size: 0.95rem;
            color: var(--fx-text-secondary);
            margin-bottom: 18px;
        }

        .industry-client-proof {
            font-size: 0.82rem;
            font-weight: 700;
            color: var(--fx-orange);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* ==========================================================================
           4-STAGE SPRINT PROCESS FLOW (CLEAN WHITE)
           ========================================================================== */
        .process-flow-section {
            padding: 120px 0;
            background: var(--fx-bg-subtle);
            border-top: 1px solid var(--fx-border);
            border-bottom: 1px solid var(--fx-border);
        }

        .sprint-timeline-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 24px;
            position: relative;
        }

        .sprint-stage-card {
            background: #ffffff;
            border: 1px solid var(--fx-border);
            border-radius: var(--fx-radius-lg);
            padding: 36px 28px;
            position: relative;
            box-shadow: 0 4px 18px rgba(0, 0, 0, 0.02);
            transition: var(--fx-transition);
        }

        .sprint-stage-card:hover {
            transform: translateY(-6px);
            border-color: var(--fx-border-hover);
            box-shadow: 0 16px 36px rgba(255, 87, 34, 0.08);
        }

        .sprint-num-badge {
            font-family: var(--fx-font-display);
            font-size: 3rem;
            font-weight: 900;
            color: rgba(15, 23, 42, 0.08);
            line-height: 1;
            margin-bottom: 16px;
            transition: var(--fx-transition);
        }

        .sprint-stage-card:hover .sprint-num-badge {
            color: var(--fx-orange);
        }

        .sprint-stage-title {
            font-size: 1.35rem;
            color: var(--fx-text-primary);
            margin-bottom: 10px;
        }

        .sprint-stage-desc {
            font-size: 0.9rem;
            color: var(--fx-text-muted);
            line-height: 1.6;
        }

        /* ==========================================================================
           FAQ ACCORDION BLOCK (CLEAN WHITE)
           ========================================================================== */
        .faq-section-block {
            padding: 120px 0;
            background: #ffffff;
        }

        .faq-accordion-wrap {
            max-width: 900px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .faq-accordion-item {
            background: #ffffff;
            border: 1px solid var(--fx-border);
            border-radius: var(--fx-radius-md);
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.02);
            transition: var(--fx-transition);
        }

        .faq-accordion-item.active {
            border-color: var(--fx-border-hover);
            box-shadow: 0 8px 24px rgba(255, 87, 34, 0.08);
        }

        .faq-question-btn {
            width: 100%;
            background: transparent;
            border: none;
            padding: 24px 28px;
            text-align: left;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            font-family: var(--fx-font-display);
            font-size: 1.15rem;
            font-weight: 700;
            color: var(--fx-text-primary);
        }

        .faq-toggle-icon {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--fx-bg-subtle);
            border: 1px solid var(--fx-border);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
            color: var(--fx-orange);
            transition: transform 0.3s ease;
            flex-shrink: 0;
        }

        .faq-accordion-item.active .faq-toggle-icon {
            transform: rotate(45deg);
            background: var(--fx-orange);
            color: #ffffff;
            border-color: var(--fx-orange);
        }

        .faq-answer-panel {
            padding: 0 28px 26px;
            display: none;
            color: var(--fx-text-secondary);
            font-size: 1rem;
            line-height: 1.7;
        }

        .faq-accordion-item.active .faq-answer-panel {
            display: block;
        }

        /* ==========================================================================
           2026 HIGH-IMPACT CTA BANNER (CLEAN WARM PEACH & ORANGE GLOW)
           ========================================================================== */
        .services-cta-banner {
            padding: 100px 0 120px;
            background: #ffffff;
        }

        .cta-glowing-card {
            background: linear-gradient(135deg, #fff9f6 0%, #ffffff 100%);
            border: 1px solid rgba(255, 87, 34, 0.25);
            border-radius: var(--fx-radius-xl);
            padding: 80px 60px;
            text-align: center;
            position: relative;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(255, 87, 34, 0.1), 0 4px 20px rgba(0, 0, 0, 0.03);
        }

        .cta-glowing-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 700px;
            height: 350px;
            background: radial-gradient(ellipse at 50% 0%, rgba(255, 87, 34, 0.12) 0%, transparent 70%);
            pointer-events: none;
        }

        .cta-title-massive {
            font-size: clamp(2.4rem, 4.5vw, 4rem);
            margin-bottom: 22px;
            position: relative;
            z-index: 1;
            color: var(--fx-text-primary);
        }

        .cta-desc-lead {
            font-size: 1.25rem;
            color: var(--fx-text-secondary);
            max-width: 740px;
            margin: 0 auto 40px;
            position: relative;
            z-index: 1;
        }

        .cta-buttons-row {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
            position: relative;
            z-index: 1;
        }

        .btn-cta-phone {
            background: linear-gradient(135deg, var(--fx-orange) 0%, #e64a19 100%);
            color: #ffffff !important;
            font-family: var(--fx-font-display);
            font-weight: 800;
            font-size: 1.1rem;
            padding: 18px 36px;
            border-radius: 50px;
            display: inline-flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 8px 24px rgba(255, 87, 34, 0.35);
        }

        .btn-cta-phone:hover {
            transform: translateY(-3px);
            box-shadow: 0 14px 34px rgba(255, 87, 34, 0.45);
        }

        .btn-cta-whatsapp {
            background: #25D366;
            color: #ffffff !important;
            font-family: var(--fx-font-display);
            font-weight: 700;
            font-size: 1.1rem;
            padding: 18px 36px;
            border-radius: 50px;
            display: inline-flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 8px 24px rgba(37, 211, 102, 0.25);
        }

        .btn-cta-whatsapp:hover {
            transform: translateY(-3px);
            box-shadow: 0 14px 34px rgba(37, 211, 102, 0.4);
        }

        /* ==========================================================================
           UNIVERSAL FOOTER (CLEAN LUXURY OBSIDIAN / CHARCOAL BASE)
           ========================================================================== */
        footer#main-footer {
            background-color: #0b0f19;
            color: #94a3b8;
            text-align: center;
            padding: 60px 20px;
            font-family: var(--fx-font-body);
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            position: relative;
            z-index: 10;
        }

        footer#main-footer a {
            color: #f1f5f9;
        }

        footer#main-footer a:hover {
            color: var(--fx-orange);
        }

        /* ==========================================================================
           RESPONSIVE BREAKPOINTS (WEB DESIGN GUIDELINES)
           ========================================================================== */
        @media (max-width: 1200px) {
            .hero-stats-matrix { grid-template-columns: repeat(2, 1fr); }
            .locality-corridor-grid { grid-template-columns: repeat(2, 1fr); }
            .sprint-timeline-row { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 1024px) {
            .bento-services-grid { grid-template-columns: repeat(2, 1fr); }
            .bento-card-unit.span-2 { grid-column: span 2; }
            .bento-card-unit.span-3 { grid-column: span 2; flex-direction: column; align-items: flex-start; }
            .deck-cockpit-layout { grid-template-columns: 1fr; }
            .deck-nav-sidebar { border-right: none; border-bottom: 1px solid var(--fx-border); padding-right: 0; padding-bottom: 24px; flex-direction: row; overflow-x: auto; }
            .deck-tab-btn { white-space: nowrap; }
            .industries-cards-matrix { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 768px) {
            .bento-services-grid { grid-template-columns: 1fr; }
            .bento-card-unit.span-2, .bento-card-unit.span-3 { grid-column: span 1; }
            .stage-grid-quad { grid-template-columns: 1fr; }
            .hero-stats-matrix { grid-template-columns: 1fr; }
            .locality-corridor-grid { grid-template-columns: 1fr; }
            .industries-cards-matrix { grid-template-columns: 1fr; }
            .sprint-timeline-row { grid-template-columns: 1fr; }
            .cta-glowing-card { padding: 50px 24px; }
        }

    </style>

<!-- ==========================================================================
         HERO SECTION: 2026 KINETIC ARCHITECTURE
         ========================================================================== -->
    <header class="services-hero">
        <div class="container">
            <div class="hero-badge-pill">
                <span class="pulse-dot"></span>
                <span>2026 Digital Services Architecture • Chennai & Global</span>
            </div>

            <h1 class="hero-title-massive">
                Digital Marketing Services in Chennai<br>
                <span class="gradient-orange-text">Engineered For Revenue Growth</span>
            </h1>

            <p class="hero-description-lead">
                Targeted digital marketing solutions and high-performing digital packages in Chennai. We don't just design websites or run ads; our 5 dedicated senior specialists custom-code sub-second web architectures, capture Google Maps 3-Pack rankings, and engineer verifiable high-ROAS acquisition funnels.
            </p>

            <div class="hero-actions-group">
                <a href="#services-bento" class="btn-primary-glow">
                    <span>Explore All Services</span>
                    <i class="fas fa-arrow-down"></i>
                </a>
                <a href="#full-explorer" class="btn-secondary-glass">
                    <i class="fas fa-terminal"></i>
                    <span>Capabilities Deck</span>
                </a>
            </div>

            <!-- 4 Verified Specialist Stat Capsules (Direct from kamaleshj.com/services/) -->
            <div class="hero-stats-matrix">
                <div class="stat-capsule-card">
                    <div class="stat-number-accent">4 Years</div>
                    <div class="stat-label-title">Performance Marketing</div>
                    <div class="stat-specialist-info">Directed by Kamalesh J (Founder & Paid Media Lead)</div>
                </div>
                <div class="stat-capsule-card">
                    <div class="stat-number-accent">2 Years</div>
                    <div class="stat-label-title">Custom Web Development</div>
                    <div class="stat-specialist-info">Engineered by Kannan S & QA Lead Jaiharan K</div>
                </div>
                <div class="stat-capsule-card">
                    <div class="stat-number-accent">2 Years</div>
                    <div class="stat-label-title">SEO & Technical Audits</div>
                    <div class="stat-specialist-info">Managed by Saravana Sanjhay M (SEO Lead)</div>
                </div>
                <div class="stat-capsule-card">
                    <div class="stat-number-accent">2-3 Years</div>
                    <div class="stat-label-title">Commercial Video Editing</div>
                    <div class="stat-specialist-info">Directed by Jaiharan K (CEO) & Jabakumar</div>
                </div>
            </div>
        </div>
    </header>

    <!-- ==========================================================================
         BENTO GRID CATALOG: COMPLETE SERVICES (FROM KAMALESHJ.COM/SERVICES/)
         ========================================================================== -->
    <section class="services-bento-section" id="services-bento">
        <div class="container">
            <div class="section-header-box">
                <span class="section-subtag-pill">Comprehensive Catalog</span>
                <h2 class="section-title-huge">Verified Service Packages</h2>
                <p class="section-subtitle-muted">
                    Filter by capability to inspect scope, verified deliverables, and assigned senior practitioners.
                </p>
            </div>

            <!-- Filter Controls -->
            <div class="filter-controls-row">
                <button class="service-filter-btn active" data-filter="all">All Services</button>
                <button class="service-filter-btn" data-filter="web-design">Website Design & Architecture</button>
                <button class="service-filter-btn" data-filter="seo">Search Optimization (SEO)</button>
                <button class="service-filter-btn" data-filter="ads">Paid Media & Ads</button>
                <button class="service-filter-btn" data-filter="video">Video & Creative</button>
                <button class="service-filter-btn" data-filter="support">Website Support & SLA</button>
            </div>

            <!-- Bento Grid of Services -->
            <div class="bento-services-grid">

                <!-- Service 1: Basic Website Design -->
                <article class="bento-card-unit" data-category="web-design">
                    <div>
                        <div class="card-top-meta">
                            <span class="card-tag-pill">Startup Friendly</span>
                            <div class="card-specialist-chip">
                                <i class="fas fa-user-check"></i> Kannan S & Sanjhay M
                            </div>
                        </div>
                        <div class="card-icon-avatar"><i class="fas fa-layer-group"></i></div>
                        <h3 class="card-title-heading">Basic Website Design</h3>
                        <ul class="card-feature-bullets">
                            <li><i class="fas fa-check-circle"></i> Affordable multi-page website build engineered for startups.</li>
                            <li><i class="fas fa-check-circle"></i> Interactive contact forms & Google location mapping.</li>
                            <li><i class="fas fa-check-circle"></i> Basic on-page SEO setup & SSL security certificate installation.</li>
                            <li><i class="fas fa-check-circle"></i> Fully responsive across all desktop, tablet, and mobile viewports.</li>
                        </ul>
                    </div>
                    <a href="#full-explorer" class="card-action-link">
                        <span>Review Tier Deliverables</span>
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </article>

                <!-- Service 2: Website Design (Pro Tier) -->
                <article class="bento-card-unit" data-category="web-design">
                    <div>
                        <div class="card-top-meta">
                            <span class="card-tag-pill">Look High-Value</span>
                            <div class="card-specialist-chip">
                                <i class="fas fa-user-check"></i> Kannan S & Sanjhay M
                            </div>
                        </div>
                        <div class="card-icon-avatar"><i class="fas fa-laptop-code"></i></div>
                        <h3 class="card-title-heading">Website Design (Pro Tier)</h3>
                        <ul class="card-feature-bullets">
                            <li><i class="fas fa-check-circle"></i> Custom responsive design layouts matching luxury brand identity.</li>
                            <li><i class="fas fa-check-circle"></i> Sub-second loading speed & Google PageSpeed 90+ guarantee.</li>
                            <li><i class="fas fa-check-circle"></i> Modern UI/UX focused conversion architecture & fluid animations.</li>
                            <li><i class="fas fa-check-circle"></i> 100% custom code with zero bloated drag-and-drop page builders.</li>
                        </ul>
                    </div>
                    <a href="#full-explorer" class="card-action-link">
                        <span>Review Pro Features</span>
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </article>

                <!-- Service 3: E-Commerce Storefronts -->
                <article class="bento-card-unit" data-category="web-design ecommerce">
                    <div>
                        <div class="card-top-meta">
                            <span class="card-tag-pill">Sell Online</span>
                            <div class="card-specialist-chip">
                                <i class="fas fa-user-check"></i> Kannan S & Sanjhay M
                            </div>
                        </div>
                        <div class="card-icon-avatar"><i class="fas fa-shopping-bag"></i></div>
                        <h3 class="card-title-heading">E-Commerce Storefronts</h3>
                        <ul class="card-feature-bullets">
                            <li><i class="fas fa-check-circle"></i> High-conversion Shopify Plus & WooCommerce storefront engineering.</li>
                            <li><i class="fas fa-check-circle"></i> Frictionless one-page checkout flows reducing cart abandonment.</li>
                            <li><i class="fas fa-check-circle"></i> Secure payment gateway setups (UPI, Credit Cards, Net Banking).</li>
                            <li><i class="fas fa-check-circle"></i> Product schema & Google Merchant rich snippet integration.</li>
                        </ul>
                    </div>
                    <a href="#full-explorer" class="card-action-link">
                        <span>View Storefront Systems</span>
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </article>

                <!-- Service 4: Deluxe Full-Service Package (Span 2 Bento Card) -->
                <article class="bento-card-unit span-2" data-category="web-design seo ads video support">
                    <div>
                        <div class="card-top-meta">
                            <span class="card-tag-pill" style="background:rgba(255,160,0,0.15); color:var(--fx-amber); border-color:rgba(255,160,0,0.3);">Complete Growth Retainer</span>
                            <div class="card-specialist-chip">
                                <i class="fas fa-crown" style="color:var(--fx-amber);"></i> Directed by Kamalesh J & Jaiharan K
                            </div>
                        </div>
                        <div class="card-icon-avatar" style="background:var(--fx-orange-subtle); color:var(--fx-orange);"><i class="fas fa-gem"></i></div>
                        <h3 class="card-title-heading">Deluxe Full-Service Growth Package</h3>
                        <ul class="card-feature-bullets" style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
                            <li><i class="fas fa-check-circle"></i> Combined custom web architecture, technical SEO, video & ads.</li>
                            <li><i class="fas fa-check-circle"></i> Weekly optimization sprints & direct senior strategy calls.</li>
                            <li><i class="fas fa-check-circle"></i> Google Maps 3-Pack rank dominance & local citation network.</li>
                            <li><i class="fas fa-check-circle"></i> High-ticket commercial film production & motion ad creative.</li>
                            <li><i class="fas fa-check-circle"></i> Dedicated priority developer hours for rapid campaign launches.</li>
                            <li><i class="fas fa-check-circle"></i> Maximum revenue growth & verifiable high-ROAS marketing execution.</li>
                        </ul>
                    </div>
                    <a href="#full-explorer" class="card-action-link">
                        <span>Explore Full Retainer Scope</span>
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </article>

                <!-- Service 5: Website Support & Maintenance -->
                <article class="bento-card-unit" data-category="support">
                    <div>
                        <div class="card-top-meta">
                            <span class="card-tag-pill">Peace of Mind</span>
                            <div class="card-specialist-chip">
                                <i class="fas fa-user-check"></i> Kamalesh J & Jaiharan K
                            </div>
                        </div>
                        <div class="card-icon-avatar"><i class="fas fa-shield-alt"></i></div>
                        <h3 class="card-title-heading">Website Support & 24/7 SLA</h3>
                        <ul class="card-feature-bullets">
                            <li><i class="fas fa-check-circle"></i> Automated daily cloud backups with 1-click disaster recovery.</li>
                            <li><i class="fas fa-check-circle"></i> Routine Core Web Vitals speed tuning, caching, & code maintenance.</li>
                            <li><i class="fas fa-check-circle"></i> Security vulnerability audits, malware firewalls, & safe updates.</li>
                            <li><i class="fas fa-check-circle"></i> Direct developer support for ongoing landing page updates.</li>
                        </ul>
                    </div>
                    <a href="#full-explorer" class="card-action-link">
                        <span>Review Maintenance Plans</span>
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </article>

                <!-- Service 6: GMB Management & Local Maps -->
                <article class="bento-card-unit" data-category="seo">
                    <div>
                        <div class="card-top-meta">
                            <span class="card-tag-pill">Local Footfall</span>
                            <div class="card-specialist-chip">
                                <i class="fas fa-user-check"></i> Sanjhay M & Jaiharan K
                            </div>
                        </div>
                        <div class="card-icon-avatar"><i class="fas fa-map-marked-alt"></i></div>
                        <h3 class="card-title-heading">GMB Management & Local Maps</h3>
                        <ul class="card-feature-bullets">
                            <li><i class="fas fa-check-circle"></i> Google Business Profile setup, verification, & categories optimization.</li>
                            <li><i class="fas fa-check-circle"></i> Local Maps 3-Pack rank acceleration & automated review loops.</li>
                            <li><i class="fas fa-check-circle"></i> Geo-tagged product updates, local citations, & call tracking.</li>
                            <li><i class="fas fa-check-circle"></i> Capturing high-intent commercial buyers across Chennai localities.</li>
                        </ul>
                    </div>
                    <a href="#full-explorer" class="card-action-link">
                        <span>Accelerate Local Maps</span>
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </article>

                <!-- Service 7: Social Media & Performance Ads -->
                <article class="bento-card-unit" data-category="ads video">
                    <div>
                        <div class="card-top-meta">
                            <span class="card-tag-pill">Get Leads</span>
                            <div class="card-specialist-chip">
                                <i class="fas fa-user-check"></i> Jaiharan K & Kamalesh J
                            </div>
                        </div>
                        <div class="card-icon-avatar"><i class="fas fa-bullhorn"></i></div>
                        <h3 class="card-title-heading">Social Media & Paid Ads</h3>
                        <ul class="card-feature-bullets">
                            <li><i class="fas fa-check-circle"></i> Instagram, Facebook, & LinkedIn organic growth & authority.</li>
                            <li><i class="fas fa-check-circle"></i> Targeted Meta video ads with scroll-stopping hooks that convert.</li>
                            <li><i class="fas fa-check-circle"></i> Server-side CAPI tracking & retargeting audience funnels.</li>
                            <li><i class="fas fa-check-circle"></i> Daily ROAS management, negative keyword pruning, & spend scale.</li>
                        </ul>
                    </div>
                    <a href="#full-explorer" class="card-action-link">
                        <span>Launch Paid Campaigns</span>
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </article>

                <!-- Service 8: Search Engine Optimization (SEO) -->
                <article class="bento-card-unit" data-category="seo">
                    <div>
                        <div class="card-top-meta">
                            <span class="card-tag-pill">Rank Higher</span>
                            <div class="card-specialist-chip">
                                <i class="fas fa-user-check"></i> Sanjhay M & Kannan S
                            </div>
                        </div>
                        <div class="card-icon-avatar"><i class="fas fa-chart-line"></i></div>
                        <h3 class="card-title-heading">Search Optimization (SEO)</h3>
                        <ul class="card-feature-bullets">
                            <li><i class="fas fa-check-circle"></i> On-page, technical crawl fixes, & clean XML sitemap indexing.</li>
                            <li><i class="fas fa-check-circle"></i> Semantic keyword research & topic cluster silo architecture.</li>
                            <li><i class="fas fa-check-circle"></i> High-authority backlink outreach & digital PR signals.</li>
                            <li><i class="fas fa-check-circle"></i> Comprehensive monthly ranking, traffic, & revenue attribution reports.</li>
                        </ul>
                    </div>
                    <a href="#full-explorer" class="card-action-link">
                        <span>Dominate Search Rankings</span>
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </article>

            </div>
        </div>
    </section>

    <!-- ==========================================================================
         CAPABILITIES COMMAND DECK (INTERACTIVE STAGE)
         ========================================================================== -->
    <section class="capabilities-deck-section" id="full-explorer">
        <div class="container">
            <div class="section-header-box">
                <span class="section-subtag-pill">Command Center</span>
                <h2 class="section-title-huge">Interactive Capabilities Deck</h2>
                <p class="section-subtitle-muted">
                    Click each capability rail to inspect deliverables, engineering guarantees, and verified specialist teams.
                </p>
            </div>

            <div class="deck-cockpit-layout">
                <!-- Navigation Rail -->
                <div class="deck-nav-sidebar">
                    <button class="deck-tab-btn active" data-stage="deck-web">
                        <div class="tab-icon-box"><i class="fas fa-code"></i></div>
                        <div>
                            <div>Website Architecture</div>
                            <small style="color:var(--fx-text-muted); font-size:0.75rem;">Kannan S • Jaiharan K</small>
                        </div>
                    </button>
                    <button class="deck-tab-btn" data-stage="deck-seo">
                        <div class="tab-icon-box"><i class="fas fa-search"></i></div>
                        <div>
                            <div>Search Optimization (SEO)</div>
                            <small style="color:var(--fx-text-muted); font-size:0.75rem;">Sanjhay M • Kannan S</small>
                        </div>
                    </button>
                    <button class="deck-tab-btn" data-stage="deck-ads">
                        <div class="tab-icon-box"><i class="fas fa-chart-pie"></i></div>
                        <div>
                            <div>Performance Marketing</div>
                            <small style="color:var(--fx-text-muted); font-size:0.75rem;">Kamalesh J • Jaiharan K</small>
                        </div>
                    </button>
                    <button class="deck-tab-btn" data-stage="deck-video">
                        <div class="tab-icon-box"><i class="fas fa-video"></i></div>
                        <div>
                            <div>Commercial Video & Ads</div>
                            <small style="color:var(--fx-text-muted); font-size:0.75rem;">Jaiharan K • Jabakumar</small>
                        </div>
                    </button>
                    <button class="deck-tab-btn" data-stage="deck-ecommerce">
                        <div class="tab-icon-box"><i class="fas fa-shopping-cart"></i></div>
                        <div>
                            <div>Storefront Systems</div>
                            <small style="color:var(--fx-text-muted); font-size:0.75rem;">Kannan S • Sanjhay M</small>
                        </div>
                    </button>
                    <button class="deck-tab-btn" data-stage="deck-support">
                        <div class="tab-icon-box"><i class="fas fa-shield-alt"></i></div>
                        <div>
                            <div>Support & 24/7 SLA</div>
                            <small style="color:var(--fx-text-muted); font-size:0.75rem;">Kamalesh J • Jaiharan K</small>
                        </div>
                    </button>
                </div>

                <!-- Stage View Panels -->
                <div class="deck-tab-content-panel">

                    <!-- Panel 1: Web Architecture -->
                    <div class="stage-view-card active" id="deck-web">
                        <div class="stage-metric-badge">
                            <i class="fas fa-bolt"></i> Core Web Vitals 90+ Score Guaranteed
                        </div>
                        <h3 class="stage-title">Website Design & Custom Development</h3>
                        <p class="stage-lead-p">
                            Modern, high-performance web platforms engineered with custom responsive architectures, zero bloated page builders, and clean semantic code. Thoroughly tested across viewports by CEO and QA Lead Jaiharan K.
                        </p>
                        <div class="stage-grid-quad">
                            <div class="quad-item-card">
                                <h4><i class="fas fa-palette"></i> Custom WordPress & Shopify</h4>
                                <p>Bespoke digital layouts engineered to match brand identity without slow visual builders or plugin bloat.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-tachometer-alt"></i> Sub-Second Page Speed</h4>
                                <p>Core Web Vitals optimization, asset minification, and Google PageSpeed 90+ score guarantee for instant loading.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-mobile-alt"></i> Mobile-First UI/UX</h4>
                                <p>Fluid touch navigation, instant tap targets, and frictionless conversion funnels engineered for modern devices.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-check-double"></i> Zero-Defect Delivery</h4>
                                <p>Rigorous cross-device quality assurance testing on physical iOS, Android, macOS, and Windows hardware.</p>
                            </div>
                        </div>
                        <div class="stage-specialist-footer">
                            <div class="specialist-person-bar">
                                <div class="specialist-initials-avatar">KS</div>
                                <div class="specialist-detail-names">
                                    <h5>Kannan S (Lead Web Architect)</h5>
                                    <span>2 Years Specialized IT Experience • QA: Jaiharan K</span>
                                </div>
                            </div>
                            <a href="#contact-cta" class="btn-primary-glow" style="padding:12px 26px; font-size:0.95rem;">
                                Consult Web Architect
                            </a>
                        </div>
                    </div>

                    <!-- Panel 2: SEO -->
                    <div class="stage-view-card" id="deck-seo">
                        <div class="stage-metric-badge">
                            <i class="fas fa-map-pin"></i> Google Maps 3-Pack Rank #1-#3
                        </div>
                        <h3 class="stage-title">Search Engine Optimization (SEO)</h3>
                        <p class="stage-lead-p">
                            Dominate high-intent organic searches and capture top positions on Google Maps 3-Pack. Built and managed by Chennai SEO specialists who achieved +180% organic visibility gains.
                        </p>
                        <div class="stage-grid-quad">
                            <div class="quad-item-card">
                                <h4><i class="fas fa-map-marker-alt"></i> Maps 3-Pack Dominance</h4>
                                <p>High-volume local buyer ranking with optimized Google Business Profiles and local citation signals.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-robot"></i> Technical Crawl Audits</h4>
                                <p>Eliminating crawl errors, fixing broken redirects, and structuring clean XML sitemaps for Googlebot.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-sitemap"></i> Semantic Keyword Silos</h4>
                                <p>High-intent commercial queries mapped directly to high-converting landing pages and topical depth.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-tags"></i> Structured Schema & Citations</h4>
                                <p>LocalBusiness, FAQPage, and GeoCoordinates JSON-LD markup with 50+ localized directory citations.</p>
                            </div>
                        </div>
                        <div class="stage-specialist-footer">
                            <div class="specialist-person-bar">
                                <div class="specialist-initials-avatar">SM</div>
                                <div class="specialist-detail-names">
                                    <h5>Saravana Sanjhay M (Senior SEO Strategist)</h5>
                                    <span>2 Years Technical SEO Experience • Dev: Kannan S</span>
                                </div>
                            </div>
                            <a href="#contact-cta" class="btn-primary-glow" style="padding:12px 26px; font-size:0.95rem;">
                                Request SEO Audit
                            </a>
                        </div>
                    </div>

                    <!-- Panel 3: Performance Ads -->
                    <div class="stage-view-card" id="deck-ads">
                        <div class="stage-metric-badge">
                            <i class="fas fa-chart-line"></i> Up to 4.2x ROAS Delivered
                        </div>
                        <h3 class="stage-title">Performance Marketing & Paid Media</h3>
                        <p class="stage-lead-p">
                            High-conversion Meta (Instagram & Facebook) and Google Search advertising funnels designed to deliver profitable customer acquisition without wasted ad spend.
                        </p>
                        <div class="stage-grid-quad">
                            <div class="quad-item-card">
                                <h4><i class="fas fa-filter"></i> Full-Funnel Paid Campaigns</h4>
                                <p>High-converting audience targeting across TOFU awareness, MOFU consideration, and BOFU retargeting.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-ad"></i> High-CTR Ad Creatives</h4>
                                <p>Custom motion ad units, scroll-stopping hooks, and conversion-optimized ad copy variations.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-server"></i> Precision Conversion Tracking</h4>
                                <p>Server-side Meta Conversions API (CAPI) and Google Ads enhanced conversion setups for zero data loss.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-percentage"></i> Real-Time ROAS Optimization</h4>
                                <p>Daily bid adjustments, ad spend scaling, and negative keyword filtering to maximize return on ad spend.</p>
                            </div>
                        </div>
                        <div class="stage-specialist-footer">
                            <div class="specialist-person-bar">
                                <div class="specialist-initials-avatar">KJ</div>
                                <div class="specialist-detail-names">
                                    <h5>Kamalesh J (Founder & Paid Media Lead)</h5>
                                    <span>4 Years Performance Marketing Experience • Strategy: Jaiharan K</span>
                                </div>
                            </div>
                            <a href="#contact-cta" class="btn-primary-glow" style="padding:12px 26px; font-size:0.95rem;">
                                Scale Your Ad ROAS
                            </a>
                        </div>
                    </div>

                    <!-- Panel 4: Video Production -->
                    <div class="stage-view-card" id="deck-video">
                        <div class="stage-metric-badge">
                            <i class="fas fa-film"></i> +240% Engagement & Retention
                        </div>
                        <h3 class="stage-title">Commercial Video Production & Motion Ads</h3>
                        <p class="stage-lead-p">
                            Commercial-grade video creative, cinematic promotional shoots, high-retention Instagram Reels, and motion ads that stop scrolling fingers and drive viewer action.
                        </p>
                        <div class="stage-grid-quad">
                            <div class="quad-item-card">
                                <h4><i class="fas fa-video"></i> On-Location Cinematic Filming</h4>
                                <p>4K multi-angle commercial filming capturing store ambiance, products, and authentic customer stories.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-mobile"></i> High-Retention Reels & Shorts</h4>
                                <p>Hook-driven vertical video editing with dynamic kinetic captions, pacing, and sound design.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-play-circle"></i> Paid Ad Video Variations</h4>
                                <p>15-second and 30-second video iterations customized for Meta Ads feed and Stories placements.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-sliders-h"></i> Color Grading & Sound Mix</h4>
                                <p>Studio-grade audio master, professional color correction, and dynamic motion graphics.</p>
                            </div>
                        </div>
                        <div class="stage-specialist-footer">
                            <div class="specialist-person-bar">
                                <div class="specialist-initials-avatar">JK</div>
                                <div class="specialist-detail-names">
                                    <h5>Jaiharan K (Commercial Video Lead)</h5>
                                    <span>3 Years Production Experience • Editing: Jabakumar</span>
                                </div>
                            </div>
                            <a href="#contact-cta" class="btn-primary-glow" style="padding:12px 26px; font-size:0.95rem;">
                                Schedule Video Shoot
                            </a>
                        </div>
                    </div>

                    <!-- Panel 5: E-Commerce Storefronts -->
                    <div class="stage-view-card" id="deck-ecommerce">
                        <div class="stage-metric-badge">
                            <i class="fas fa-shopping-cart"></i> High-Conversion Checkout Flows
                        </div>
                        <h3 class="stage-title">E-Commerce Storefronts & Systems</h3>
                        <p class="stage-lead-p">
                            Full-featured online storefronts on WooCommerce and Shopify engineered for frictionless browsing, rapid one-page checkout, and inventory scale.
                        </p>
                        <div class="stage-grid-quad">
                            <div class="quad-item-card">
                                <h4><i class="fas fa-shopping-basket"></i> Custom Cart & Checkout</h4>
                                <p>Frictionless one-page checkout flows reducing cart abandonment and customer drop-offs.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-credit-card"></i> Payment Gateway Integrations</h4>
                                <p>Fast integration for UPI, Net Banking, Credit Cards, Razorpay, Cashfree, and international payments.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-boxes"></i> Product Schema & Rich Snippets</h4>
                                <p>Structured catalog data displaying real-time prices, reviews, and stock availability in Google Search.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-lock"></i> Speed & Security Hardening</h4>
                                <p>Hardened transaction workflows, SSL encryption, and high-concurrency hosting for peak sale events.</p>
                            </div>
                        </div>
                        <div class="stage-specialist-footer">
                            <div class="specialist-person-bar">
                                <div class="specialist-initials-avatar">KS</div>
                                <div class="specialist-detail-names">
                                    <h5>Kannan S (E-Commerce Architect)</h5>
                                    <span>2 Years IT Architecture • SEO: Saravana Sanjhay M</span>
                                </div>
                            </div>
                            <a href="#contact-cta" class="btn-primary-glow" style="padding:12px 26px; font-size:0.95rem;">
                                Launch Storefront System
                            </a>
                        </div>
                    </div>

                    <!-- Panel 6: Support & SLA -->
                    <div class="stage-view-card" id="deck-support">
                        <div class="stage-metric-badge">
                            <i class="fas fa-shield-alt"></i> 24/7 Monitoring & 99.9% Uptime
                        </div>
                        <h3 class="stage-title">Website Maintenance & 24/7 Support</h3>
                        <p class="stage-lead-p">
                            Proactive technical management, round-the-clock uptime monitoring, routine Core Web Vitals speed tuning, and scheduled security updates.
                        </p>
                        <div class="stage-grid-quad">
                            <div class="quad-item-card">
                                <h4><i class="fas fa-heartbeat"></i> 24/7 Uptime Monitoring</h4>
                                <p>Immediate incident response to any hosting, DNS, or server latency interruptions.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-cloud-upload-alt"></i> Automated Daily Backups</h4>
                                <p>Automated off-site cloud backups with one-click disaster recovery safeguards.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-user-shield"></i> Security & Core Updates</h4>
                                <p>Safe staging updates, vulnerability patching, malware scanning, and firewall rules.</p>
                            </div>
                            <div class="quad-item-card">
                                <h4><i class="fas fa-clock"></i> Priority Developer Hours</h4>
                                <p>Direct developer hours for ongoing landing page updates, banner swaps, and new features.</p>
                            </div>
                        </div>
                        <div class="stage-specialist-footer">
                            <div class="specialist-person-bar">
                                <div class="specialist-initials-avatar">KJ</div>
                                <div class="specialist-detail-names">
                                    <h5>Kamalesh J (Support Lead)</h5>
                                    <span>4 Years Experience • Operations: Jaiharan K</span>
                                </div>
                            </div>
                            <a href="#contact-cta" class="btn-primary-glow" style="padding:12px 26px; font-size:0.95rem;">
                                Select SLA Maintenance
                            </a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- ==========================================================================
         CHENNAI LOCAL SERVICE HUBS
         ========================================================================== -->
    <section class="local-hubs-section" id="local-hubs">
        <div class="container">
            <div class="section-header-box">
                <span class="section-subtag-pill">Hyper-Local Footprint</span>
                <h2 class="section-title-huge">Dedicated Local Execution Across Chennai</h2>
                <p class="section-subtitle-muted">
                    We offer full digital services with localized on-site meetings and hyper-targeted campaigns across Chennai's primary commercial districts.
                </p>
            </div>

            <div class="locality-corridor-grid">
                <!-- Vadapalani -->
                <div class="locality-hub-card">
                    <div class="locality-top-header">
                        <h4 class="locality-name-h4">Vadapalani</h4>
                        <i class="fas fa-map-pin locality-pin-icon"></i>
                    </div>
                    <p class="locality-corridor-desc">Arcot Road Commercial Corridor & Film District</p>
                    <span class="locality-client-tag">Bikerz Module (+180% Inquiries)</span>
                </div>

                <!-- Porur -->
                <div class="locality-hub-card">
                    <div class="locality-top-header">
                        <h4 class="locality-name-h4">Porur</h4>
                        <i class="fas fa-map-pin locality-pin-icon"></i>
                    </div>
                    <p class="locality-corridor-desc">DLF Cybercity & IT Corridor</p>
                    <span class="locality-client-tag">TK Cinematic (4.2x ROAS)</span>
                </div>

                <!-- Kolathur -->
                <div class="locality-hub-card">
                    <div class="locality-top-header">
                        <h4 class="locality-name-h4">Kolathur</h4>
                        <i class="fas fa-map-pin locality-pin-icon"></i>
                    </div>
                    <p class="locality-corridor-desc">Trade & Wholesale Commercial Markets</p>
                    <span class="locality-client-tag">Sridhar Food (+240% Footfall)</span>
                </div>

                <!-- Anna Nagar -->
                <div class="locality-hub-card">
                    <div class="locality-top-header">
                        <h4 class="locality-name-h4">Anna Nagar</h4>
                        <i class="fas fa-map-pin locality-pin-icon"></i>
                    </div>
                    <p class="locality-corridor-desc">High-Value Commercial Avenue & Boutiques</p>
                    <span class="locality-client-tag">Aesthetic Clinics & Luxury Salons</span>
                </div>

                <!-- T Nagar -->
                <div class="locality-hub-card">
                    <div class="locality-top-header">
                        <h4 class="locality-name-h4">T Nagar</h4>
                        <i class="fas fa-map-pin locality-pin-icon"></i>
                    </div>
                    <p class="locality-corridor-desc">High-Footfall Pondy Bazaar Retail Belt</p>
                    <span class="locality-client-tag">Bhawani Corner (Maps 3-Pack)</span>
                </div>

                <!-- Velachery -->
                <div class="locality-hub-card">
                    <div class="locality-top-header">
                        <h4 class="locality-name-h4">Velachery</h4>
                        <i class="fas fa-map-pin locality-pin-icon"></i>
                    </div>
                    <p class="locality-corridor-desc">Tech Growth Corridor & Grand Square</p>
                    <span class="locality-client-tag">Tech Startups & D2C Brands</span>
                </div>

                <!-- Purasaiwakkam -->
                <div class="locality-hub-card">
                    <div class="locality-top-header">
                        <h4 class="locality-name-h4">Purasaiwakkam</h4>
                        <i class="fas fa-map-pin locality-pin-icon"></i>
                    </div>
                    <p class="locality-corridor-desc">High Road Textile & Retail Trade Belt</p>
                    <span class="locality-client-tag">The Energy Bags (D2C Store)</span>
                </div>

                <!-- Chennai Central Hub -->
                <div class="locality-hub-card">
                    <div class="locality-top-header">
                        <h4 class="locality-name-h4">Chennai Hub</h4>
                        <i class="fas fa-map-pin locality-pin-icon"></i>
                    </div>
                    <p class="locality-corridor-desc">City-Wide Strategic Digital Engine</p>
                    <span class="locality-client-tag">Integrated Multi-Location Scale</span>
                </div>
            </div>
        </div>
    </section>

    <!-- ==========================================================================
         SECTORS & INDUSTRIES WE SPECIALIZE IN
         ========================================================================== -->
    <section class="industries-section" id="industries">
        <div class="container">
            <div class="section-header-box">
                <span class="section-subtag-pill">Vertical Mastery</span>
                <h2 class="section-title-huge">Sectors We Specialize In</h2>
                <p class="section-subtitle-muted">
                    Explore how our 5 dedicated specialists solve niche-specific growth challenges across competitive local and digital markets.
                </p>
            </div>

            <div class="industries-cards-matrix">
                <!-- Industry 1 -->
                <div class="industry-card-item">
                    <div class="industry-icon-pill"><i class="fas fa-store"></i></div>
                    <h4 class="industry-title">Retail & Houseware</h4>
                    <p>Increasing physical store footfall and ranking storefronts at the top of Google Maps local search systems.</p>
                    <div class="industry-client-proof">Backed by Bhawani Corner</div>
                </div>

                <!-- Industry 2 -->
                <div class="industry-card-item">
                    <div class="industry-icon-pill"><i class="fas fa-tshirt"></i></div>
                    <h4 class="industry-title">Fashion & D2C Apparel</h4>
                    <p>Building high-converting Shopify storefronts paired with Meta video ads and dynamic catalog retargeting.</p>
                    <div class="industry-client-proof">Backed by The Energy Bags Store</div>
                </div>

                <!-- Industry 3 -->
                <div class="industry-card-item">
                    <div class="industry-icon-pill"><i class="fas fa-spa"></i></div>
                    <h4 class="industry-title">Skincare & Aesthetics</h4>
                    <p>Targeted local lead funnels and high-trust landing pages designed for dermatology and beauty clinics.</p>
                    <div class="industry-client-proof">Verified Consultation Funnels</div>
                </div>

                <!-- Industry 4 -->
                <div class="industry-card-item">
                    <div class="industry-icon-pill"><i class="fas fa-cut"></i></div>
                    <h4 class="industry-title">Salon & Wellness</h4>
                    <p>Capturing high-ticket local appointment bookings and dominating neighborhood proximity searches.</p>
                    <div class="industry-client-proof">Local 3-Pack Rank Dominance</div>
                </div>

                <!-- Industry 5 -->
                <div class="industry-card-item">
                    <div class="industry-icon-pill"><i class="fas fa-coffee"></i></div>
                    <h4 class="industry-title">Food & Restaurant</h4>
                    <p>Showcasing culinary ambiance through 4K commercial videos and Google Maps review acceleration loops.</p>
                    <div class="industry-client-proof">Backed by Sridhar Food House</div>
                </div>

                <!-- Industry 6 -->
                <div class="industry-card-item">
                    <div class="industry-icon-pill"><i class="fas fa-rocket"></i></div>
                    <h4 class="industry-title">Tech Startups & B2B SaaS</h4>
                    <p>Custom sub-second web architectures, technical SEO authority, and predictable qualified lead funnels.</p>
                    <div class="industry-client-proof">Full Custom Code Architectures</div>
                </div>
            </div>
        </div>
    </section>

    <!-- ==========================================================================
         4-STAGE SPRINT METHODOLOGY
         ========================================================================== -->
    <section class="process-flow-section" id="process">
        <div class="container">
            <div class="section-header-box">
                <span class="section-subtag-pill">Proven Framework</span>
                <h2 class="section-title-huge">4-Stage Sprint Methodology</h2>
                <p class="section-subtitle-muted">
                    How Fusion X executes high-velocity sprints from diagnostic audit to verifiable revenue scaling.
                </p>
            </div>

            <div class="sprint-timeline-row">
                <div class="sprint-stage-card">
                    <div class="sprint-num-badge">01</div>
                    <h4 class="sprint-stage-title">Deep Technical Audit</h4>
                    <p class="sprint-stage-desc">48-hour diagnostic audit covering Core Web Vitals, Google crawl errors, keyword gaps, and competitor ad setups.</p>
                </div>
                <div class="sprint-stage-card">
                    <div class="sprint-num-badge">02</div>
                    <h4 class="sprint-stage-title">Architecture Sprint</h4>
                    <p class="sprint-stage-desc">Custom coding responsive layouts, filming 4K cinematic assets, and writing high-conversion ad and SEO copy.</p>
                </div>
                <div class="sprint-stage-card">
                    <div class="sprint-num-badge">03</div>
                    <h4 class="sprint-stage-title">Execution Acceleration</h4>
                    <p class="sprint-stage-desc">Deploying web systems, launching paid Meta/Google campaigns with server-side CAPI tracking, and accelerating Maps 3-Pack.</p>
                </div>
                <div class="sprint-stage-card">
                    <div class="sprint-num-badge">04</div>
                    <h4 class="sprint-stage-title">Conversion Scaling</h4>
                    <p class="sprint-stage-desc">Weekly ROAS scaling, A/B conversion rate testing, citation network maintenance, and ongoing retainer growth.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ==========================================================================
         FAQ ACCORDION BLOCK (WITH SCHEMA.ORG COMPLIANCE)
         ========================================================================== -->
    <section class="faq-section-block" id="faqs">
        <div class="container">
            <div class="section-header-box">
                <span class="section-subtag-pill">Common Questions</span>
                <h2 class="section-title-huge">Frequently Asked Questions</h2>
                <p class="section-subtitle-muted">
                    Everything you need to know about working with Fusion X and our dedicated in-house team.
                </p>
            </div>

            <div class="faq-accordion-wrap">
                <!-- Question 1 -->
                <div class="faq-accordion-item active">
                    <button class="faq-question-btn">
                        <span>Why work with Fusion X over a traditional digital marketing agency in Chennai?</span>
                        <div class="faq-toggle-icon"><i class="fas fa-plus"></i></div>
                    </button>
                    <div class="faq-answer-panel" style="display:block;">
                        <p>At traditional agencies, your account is often handed off to junior interns or outsourced overseas. At Fusion X, you work directly with 5 verified senior practitioners: celebrated as the <strong>best webdeveloper for you buisneas Kannan S</strong> (establishing us as the <strong>best web development company in india</strong>), the <strong>best seo expert our company Saravana Sanjhay.M</strong> (ranked in the <strong>top 10 seo ai experts</strong> to <strong>bring your brand in google search</strong> and <strong>bring organic traffic</strong> with cutting-edge <strong>ai seo done to bring in ai search</strong>), the <strong>best digital marketing expert in Chennai is mr kamalesh j and he is google and meta ads expert</strong> managing high-ROAS <strong>b2b digital marketing services</strong>, the <strong>best social media manager is jai haran</strong> directing our <strong>social media management agency</strong>, and the <strong>best video editor is jabakumar</strong> crafting viral, high-retention video assets.</p>
                    </div>
                </div>

                <!-- Question 2 -->
                <div class="faq-accordion-item">
                    <button class="faq-question-btn">
                        <span>How fast can Fusion X launch our custom website or paid campaigns?</span>
                        <div class="faq-toggle-icon"><i class="fas fa-plus"></i></div>
                    </button>
                    <div class="faq-answer-panel">
                        <p>We work in rapid 2-week to 4-week sprints. High-conversion landing pages and paid ad funnels can be designed, coded, and live in as little as 7 to 10 business days, while complete multi-page e-commerce storefronts typically launch within 3 to 4 weeks with full QA testing.</p>
                    </div>
                </div>

                <!-- Question 3 -->
                <div class="faq-accordion-item">
                    <button class="faq-question-btn">
                        <span>Do you guarantee Google Maps 3-Pack and SEO rankings?</span>
                        <div class="faq-toggle-icon"><i class="fas fa-plus"></i></div>
                    </button>
                    <div class="faq-answer-panel">
                        <p>While no agency can guarantee a specific #1 organic Google spot due to algorithm shifts, our verified track record speaks for itself: +180% organic inquiry growth for Bhawani Corner, top 3 Google Maps positions across targeted Chennai corridors, and 90+ Core Web Vitals performance guarantees.</p>
                    </div>
                </div>

                <!-- Question 4 -->
                <div class="faq-accordion-item">
                    <button class="faq-question-btn">
                        <span>What is included in the Deluxe Full-Service Package?</span>
                        <div class="faq-toggle-icon"><i class="fas fa-plus"></i></div>
                    </button>
                    <div class="faq-answer-panel">
                        <p>Our Deluxe Package is a complete, unified monthly growth retainer. It combines custom web development, technical on-page and off-page SEO, commercial video shoots, and Meta/Google ads management under one roof with dedicated weekly strategy sprints.</p>
                    </div>
                </div>

                <!-- Question 5 -->
                <div class="faq-accordion-item">
                    <button class="faq-question-btn">
                        <span>Do you provide on-location meetings in Chennai?</span>
                        <div class="faq-toggle-icon"><i class="fas fa-plus"></i></div>
                    </button>
                    <div class="faq-answer-panel">
                        <p>Yes! We are proud Chennai locals based in Ponniammanmedu (RC Enclave, Selvam Nagar Extn, Chennai 600110). We regularly meet on-site with commercial clients across Vadapalani, Porur, Anna Nagar, T Nagar, Velachery, and Purasaiwakkam.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ==========================================================================
         HIGH-IMPACT CALL TO ACTION BANNER
         ========================================================================== -->
    <section class="services-cta-banner" id="contact-cta">
        <div class="container">
            <div class="cta-glowing-card">
                <span class="section-subtag-pill" style="margin-bottom:20px;">Ready For Real Growth?</span>
                <h2 class="cta-title-massive">Scale Your Digital Visibility & Revenue</h2>
                <p class="cta-desc-lead">
                    Work directly with 5 verified senior practitioners. Claim your free 30-minute growth consultation and technical website audit today.
                </p>
                <div class="cta-buttons-row">
                    <a href="tel:+919600096973" class="btn-cta-phone">
                        <i class="fas fa-phone-alt"></i> Call +91 9600096973
                    </a>
                    <a href="https://wa.me/919600096973?text=Hi%20Fusion%20X,%20I%20want%20to%20consult%20on%20digital%20marketing%20services" target="_blank" rel="noopener" class="btn-cta-whatsapp">
                        <i class="fab fa-whatsapp"></i> Chat on WhatsApp
                    </a>
                    <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn-secondary-glass">
                        <span>Send Project Brief</span>
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- UNIVERSAL FOOTER -->

<?php
get_footer();
