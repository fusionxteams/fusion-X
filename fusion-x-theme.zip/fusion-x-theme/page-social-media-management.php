<?php
/**
 * Template Name: Social Media Management
 *
 * @package Fusion_X
 */

get_header();
?>

<style>
        :root {
            --smm-orange: #ff5722;
            --smm-orange-dark: #e64a19;
            --smm-dark: #0f172a;
            --smm-muted: #64748b;
        }

        body {
            font-family: 'Space Grotesk', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: #ffffff;
            color: #1e293b;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        /* ── HERO ── */
        .page-hero {
            padding: 150px 24px 80px;
            background: radial-gradient(circle at 50% 20%, rgba(255, 87, 34, 0.06) 0%, transparent 60%),
                        #ffffff;
            text-align: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .badge-pill {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 8px 24px;
            background: rgba(255, 87, 34, 0.08);
            border: 1px solid rgba(255, 87, 34, 0.25);
            border-radius: 50px;
            font-size: 0.82rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: var(--smm-orange);
            margin-bottom: 24px;
        }

        .hero-title {
            font-family: 'Outfit', sans-serif;
            font-size: clamp(2.5rem, 5.5vw, 4.6rem);
            font-weight: 900;
            line-height: 1.08;
            letter-spacing: -1.5px;
            color: #0f172a;
            max-width: 980px;
            margin: 0 auto 24px;
        }

        .hero-title span {
            background: linear-gradient(135deg, #ff5722 20%, #ff8a50 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .hero-desc {
            font-size: clamp(1.05rem, 2vw, 1.25rem);
            line-height: 1.7;
            color: var(--smm-muted);
            max-width: 800px;
            margin: 0 auto 40px;
        }

        .tech-chips {
            display: flex;
            justify-content: center;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 50px;
        }

        .tech-chip {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 18px;
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 50px;
            font-size: 0.88rem;
            font-weight: 700;
            color: #334155;
            box-shadow: 0 4px 12px rgba(0,0,0,0.03);
        }

        .tech-chip i {
            color: var(--smm-orange);
        }

        /* ── SERVICES DETAIL CONTAINER ── */
        .content-section {
            padding: 90px 24px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .service-card-block {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px;
            align-items: center;
            padding: 60px 0;
            border-bottom: 1px solid #f1f5f9;
        }

        .service-card-block:nth-child(even) {
            direction: rtl;
        }

        .service-card-block:nth-child(even) .card-text-col {
            direction: ltr;
        }

        .service-card-block:nth-child(even) .card-visual-col {
            direction: ltr;
        }

        .card-tag {
            display: inline-block;
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 2.5px;
            text-transform: uppercase;
            color: var(--smm-orange);
            margin-bottom: 12px;
        }

        .card-h2 {
            font-family: 'Outfit', sans-serif;
            font-size: clamp(2rem, 3.5vw, 2.8rem);
            font-weight: 800;
            line-height: 1.15;
            color: #0f172a;
            margin-bottom: 18px;
        }

        .card-p {
            font-size: 1.02rem;
            color: #475569;
            line-height: 1.75;
            margin-bottom: 24px;
        }

        .card-feature-list {
            list-style: none;
            padding: 0;
            margin: 0 0 30px;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .card-feature-list li {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 0.95rem;
            font-weight: 600;
            color: #334155;
        }

        .card-feature-list li i {
            color: var(--smm-orange);
            font-size: 1rem;
        }

        .card-tech-tag {
            display: inline-block;
            background: #f1f5f9;
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 0.8rem;
            font-weight: 700;
            color: #475569;
            margin-right: 8px;
        }

        .card-visual-box {
            background: linear-gradient(135deg, #f8fafc 0%, #edf2f7 100%);
            border: 1px solid #e2e8f0;
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.05);
            text-align: center;
        }

        .card-visual-icon {
            font-size: 4rem;
            color: var(--smm-orange);
            margin-bottom: 20px;
        }

        .card-visual-stat {
            font-family: 'Outfit', sans-serif;
            font-size: 2.8rem;
            font-weight: 900;
            color: #0f172a;
            margin-bottom: 6px;
        }

        .card-visual-sub {
            font-size: 0.92rem;
            color: var(--smm-muted);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .cta-banner {
            background: #080808; border: 1px solid rgba(255, 87, 34, 0.3);
            border-radius: 28px;
            padding: 60px 40px;
            text-align: center;
            color: #ffffff;
            margin: 60px auto 0;
            max-width: 1100px;
        }

        .cta-banner h2 {
            font-family: 'Outfit', sans-serif;
            font-size: clamp(2rem, 4vw, 3rem);
            font-weight: 900;
            margin-bottom: 14px;
        }

        .cta-banner p {
            font-size: 1.1rem;
            color: #cbd5e1;
            max-width: 650px;
            margin: 0 auto 30px;
        }

        .btn-banner {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 16px 36px;
            background: var(--smm-orange);
            color: #ffffff;
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 800;
            font-size: 1rem;
            border-radius: 50px;
            text-decoration: none;
            box-shadow: 0 8px 25px rgba(255, 87, 34, 0.4);
            transition: all 0.3s ease;
        }

        .btn-banner:hover {
            background: var(--smm-orange-dark);
            transform: translateY(-2px);
        }

        @media (max-width: 900px) {
            .service-card-block {
                grid-template-columns: 1fr;
                gap: 30px;
                padding: 40px 0;
            }
            .service-card-block:nth-child(even) {
                direction: ltr;
            }
        }
    </style>

<!-- ═══════════════════════ HERO ═══════════════════════ -->
    <section class="page-hero">
        <div class="badge-pill">
            <i class="fa-solid fa-share-nodes"></i> SOCIAL MEDIA EXCELLENCE
        </div>
        <h1 class="hero-title">
            Grow an Obsessed Audience with <span>Viral-Velocity Content</span>
        </h1>
        <p class="hero-desc">
            We turn passive scrollers into dedicated brand advocates. From psychological hook writing and high-retention video editing to cohesive aesthetic visual design that commands prestige.
        </p>

        <div class="tech-chips">
            <span class="tech-chip"><i class="fa-solid fa-pen-nib"></i> Viral Copywriting</span>
            <span class="tech-chip"><i class="fa-solid fa-film"></i> Short-Form Video Editing</span>
            <span class="tech-chip"><i class="fa-solid fa-palette"></i> Aesthetic Feed Architecture</span>
            <span class="tech-chip"><i class="fa-brands fa-instagram"></i> Instagram, LinkedIn & YouTube</span>
        </div>
    </section>

    <!-- ═══════════════════════ DETAILED SERVICES ═══════════════════════ -->
    <main class="content-section">
        
        <!-- 1. Content Writing -->
        <section id="content-writing" class="service-card-block">
            <div class="card-text-col">
                <span class="card-tag">PSYCHOLOGICAL HOOKS</span>
                <h2 class="card-h2">High-Retention Content Writing</h2>
                <p class="card-p">
                    Words that command attention in the first 1.5 seconds. We script viral reel hooks, carousel narratives, long-form LinkedIn thought-leadership essays, and magnetic brand bios that spark conversations, shares, and direct messages.
                </p>
                <ul class="card-feature-list">
                    <li><i class="fa-solid fa-check"></i> Pattern-interrupt hook formulas tailored to your audience persona</li>
                    <li><i class="fa-solid fa-check"></i> 10-slide educational carousels with high save-and-share ratios</li>
                    <li><i class="fa-solid fa-check"></i> Executive founder thought-leadership posts for personal branding</li>
                    <li><i class="fa-solid fa-check"></i> Strategic hashtag & keyword optimization for platform search reach</li>
                </ul>
                <div>
                    <span class="card-tech-tag">Direct Response</span>
                    <span class="card-tech-tag">Viral Hooks</span>
                    <span class="card-tech-tag">LinkedIn & Insta</span>
                </div>
            </div>
            <div class="card-visual-col">
                <div class="card-visual-box">
                    <div class="card-visual-icon"><i class="fa-solid fa-pen-fancy"></i></div>
                    <div class="card-visual-stat">4.2x</div>
                    <div class="card-visual-sub">Higher Average Post Engagement</div>
                </div>
            </div>
        </section>

        <!-- 2. Video Editing -->
        <section id="video-editing" class="service-card-block">
            <div class="card-text-col">
                <span class="card-tag">THUMB-STOPPING MOTION</span>
                <h2 class="card-h2">Cinematic Short-Form Video Editing</h2>
                <p class="card-p">
                    We edit raw footage into dynamic, fast-paced Reels, YouTube Shorts, and TikToks designed around algorithmic watch time. Featuring kinetic typography captions, custom sound effects, color grading, seamless b-roll cuts, and meme cultural timing.
                </p>
                <ul class="card-feature-list">
                    <li><i class="fa-solid fa-check"></i> Kinetic animated captions, sound effects (SFX) & dynamic zoom cuts</li>
                    <li><i class="fa-solid fa-check"></i> 60fps color correction & cinematic brand grading (Rec.709)</li>
                    <li><i class="fa-solid fa-check"></i> Podcast cutdowns, commercial teasers & product spotlight reels</li>
                    <li><i class="fa-solid fa-check"></i> Fast 24-48 hour turnaround on weekly batch deliverables</li>
                </ul>
                <div>
                    <span class="card-tech-tag">Premiere Pro</span>
                    <span class="card-tech-tag">After Effects</span>
                    <span class="card-tech-tag">Reels / Shorts</span>
                </div>
            </div>
            <div class="card-visual-col">
                <div class="card-visual-box">
                    <div class="card-visual-icon"><i class="fa-solid fa-video"></i></div>
                    <div class="card-visual-stat">85%+</div>
                    <div class="card-visual-sub">Average Video Completion Rate</div>
                </div>
            </div>
        </section>

        <!-- 3. Content Creation -->
        <section id="content-creation" class="service-card-block">
            <div class="card-text-col">
                <span class="card-tag">BRAND AESTHETICS</span>
                <h2 class="card-h2">Visual Content Creation & Feed Design</h2>
                <p class="card-p">
                    Turn your Instagram grid into a luxury digital showroom. Our visual designers build cohesive brand design systems, custom iconographies, story highlight suites, product feature banners, and weekly content calendars that keep your brand omnipresent.
                </p>
                <ul class="card-feature-list">
                    <li><i class="fa-solid fa-check"></i> Bespoke color palette, typographic hierarchy & aesthetic grid planning</li>
                    <li><i class="fa-solid fa-check"></i> 30-day comprehensive content calendars with pre-scheduled publishing</li>
                    <li><i class="fa-solid fa-check"></i> Interactive story templates, poll designs & seasonal festival creatives</li>
                    <li><i class="fa-solid fa-check"></i> Community management, comment response playbooks & DM nurturing</li>
                </ul>
                <div>
                    <span class="card-tech-tag">Figma & Photoshop</span>
                    <span class="card-tech-tag">Monthly Calendar</span>
                    <span class="card-tech-tag">Brand Identity</span>
                </div>
            </div>
            <div class="card-visual-col">
                <div class="card-visual-box">
                    <div class="card-visual-icon"><i class="fa-solid fa-swatchbook"></i></div>
                    <div class="card-visual-stat">30 Days</div>
                    <div class="card-visual-sub">Predictable Done-For-You Content Pipeline</div>
                </div>
            </div>
        </section>

        <!-- CTA BANNER -->
        <div class="cta-banner">
            <h2>Ready to Dominate Your Social Feeds?</h2>
            <p>Let our creative team craft a bespoke 30-day viral roadmap, video sample, and aesthetic moodboard for your brand.</p>
            <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn-banner">
                <i class="fa-solid fa-paper-plane"></i> Request Your Free Audit
            </a>
        </div>
    </main>

    <!-- ═══════════════════════ FOOTER ═══════════════════════ -->
        
    <!-- ═══════════════════════ TEAM SPECIALIST SPOTLIGHT ═══════════════════════ -->
    <section class="expert-spotlight-section">
        <div class="expert-spotlight-card">
            <div class="expert-avatar-wrap">
                <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/team/jaiharan-k-ceo-social-media-manager-fusion-x.webp" alt="Jai Haran - Best Social Media Manager &amp; Community Growth Lead" class="expert-avatar-img">
                <div class="expert-verified-badge"><i class="fa-solid fa-check"></i></div>
            </div>
            <div class="expert-content">
                <div class="expert-domain-pill"><i class="fa-solid fa-share-nodes"></i> Social Media & Community Growth Lead</div>
                <h3 class="expert-name">Jai Haran</h3>
                <div class="expert-headline">
                    <i class="fa-solid fa-award" style="color: #ff5722;"></i>
                    <strong>best social media manager is jai haran</strong>
                </div>
                <p class="expert-bio">
                    Directing our elite <strong>social media management agency</strong>, the <strong>best social media manager is jai haran</strong>. Jai creates viral distribution strategies, cultural content calendars, and engagement engines that turn passive social scrollers into loyal customers. Collaborating closely with our post-production team where the <strong>best video editor is jabakumar</strong>, Jai Haran ensures your brand commands attention across Instagram, LinkedIn, and YouTube.
                </p>
                <div class="expert-stats-row">
                    <div class="expert-stat-item">
                        <span class="expert-stat-val">1.4M+</span>
                        <span class="expert-stat-lbl">Audience Impressions</span>
                    </div>
                    <div class="expert-stat-item">
                        <span class="expert-stat-val">8.4%</span>
                        <span class="expert-stat-lbl">Average Engagement Rate</span>
                    </div>
                    <div class="expert-stat-item">
                        <span class="expert-stat-val">100%</span>
                        <span class="expert-stat-lbl">Organic Community Growth</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php
get_footer();
